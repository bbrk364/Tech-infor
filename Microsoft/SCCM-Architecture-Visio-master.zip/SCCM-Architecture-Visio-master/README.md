# SCCM-Architecture-Visio #throwback
Here is the sample visio diagram for SCCM Architecture which supports Windows 10 co-management with Intune
Feel free to download and update the files to include new features of SCCM like Active Passive server architecture
More queries - Contact me @anoopmannur https://www.anoopcnair.com/download-sccm-architecture-visio/
NOTE! - I didn't embed any water mark in the diagram. So, feel free to use this as a template for your projects. And keep this version updates via GitHub.
