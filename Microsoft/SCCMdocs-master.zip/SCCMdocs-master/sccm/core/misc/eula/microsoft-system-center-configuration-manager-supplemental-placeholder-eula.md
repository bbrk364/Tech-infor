---
title: "MICROSOFT SYSTEM CENTER CONFIGURATION MANAGER SUPPLEMENTAL PLACEHOLDER EULA"
ms.custom: na
ms.date: 10/06/2016
ms.reviewer: na
ms.suite: na
ms.tgt_pltfrm: na
ms.prod: configuration-manager
ms.technology:
 - configmgr-other
ms.service: configmgr-other
ms.assetid: 4043e457-56c5-4b93-8dfd-87ad3277a7a1
caps.latest.revision: 3
author: aczechowski
ms.author: aaroncz
manager: angrobe
robots: noindex,nofollow
---
# MICROSOFT SYSTEM CENTER CONFIGURATION MANAGER SUPPLEMENTAL PLACEHOLDER EULA

*Applies to: System Center Configuration Manager (Current Branch)*

MICROSOFT SYSTEM CENTER CONFIGURATION MANAGER SUPPLEMENTAL PLACEHOLDER EULA
