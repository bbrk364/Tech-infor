---
title: "MICROSOFT SYSTEM CENTER ENDPOINT PROTECTION"
titleSuffix: "Configuration Manager"
ms.custom: na
ms.date: 10/06/2016
ms.reviewer: na
ms.suite: na
ms.tgt_pltfrm: na
ms.topic: article
ms.prod: configuration-manager
ms.service:
ms.technology:
 - configmgr-other
ms.assetid: e9704758-9572-49b6-a66f-fd480b9e3e20
caps.latest.revision: 4
author: aczechowski
ms.author: aaroncz
manager: angrobe
robots: noindex,nofollow

---
# MICROSOFT SYSTEM CENTER ENDPOINT PROTECTION


**PLEASE NOTE:** Your use of this software is subject to the terms and conditions of the license agreement by which you (or your company) acquired the Microsoft server software or gained access to the online service from Microsoft. For instance, if you are:  

-   a volume license customer or service provider, use of this software is subject to your volume license agreement or service provider license agreement;  

-   a MSDN customer, use of this software is subject to the MSDN license agreement;  

-   a customer that received the software separately from a hardware manufacturer or system builder, use of this software is subject to the license agreement with that part;  

-   an online service customer, use of this software is subject to the online subscription agreement.  

You may not use this software if you have not validly acquired a license for the software or online service from Microsoft or its licensed distributors.
